package com.example.aquaculturewirelessmonitoring2;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    TextView temperatureText;
    TextView DOText;
    TextView pHText;
    TextView sensor4Text;
    TextView sensor5Text;
    TextView sensor6Text;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        temperatureText = findViewById(R.id.temperatureText);
        DOText = findViewById(R.id.DOText);
        pHText = findViewById(R.id.pHText);
        sensor4Text = findViewById(R.id.sensor4Text);
        sensor5Text = findViewById(R.id.sensor5Text);
        sensor6Text = findViewById(R.id.sensor6Text);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference temperatureRef = database.getReference("Temprature");
        DatabaseReference DORef = database.getReference("Dissolved_oxygen");
        DatabaseReference pHRef = database.getReference("pH");
        DatabaseReference sensor4Ref = database.getReference("sensorData4");
        DatabaseReference sensor5Ref = database.getReference("sensorData5");
        DatabaseReference sensor6Ref = database.getReference("sensorData6");

        temperatureRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                String newValue =    value  + " Celcius";
                temperatureText.setText(newValue);
                String title = "Temperature Alert";
                String subject = " Your Temperature needs calibration !";
                String body = "The current Temperature is: " + value;
                Integer tempratureInt = Integer.parseInt(value);

                //Edit the conditions here
                if (tempratureInt > 512)
                {
                    startService(body);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Temperature value not available !!", Toast.LENGTH_SHORT).show();

            }
        });

        DORef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                String newValue =    value  + " ml per Litre";
                DOText.setText(newValue);
                String title = "DO Alert";
                String subject = " Your DO Value needs calibration !";
                String body = "The current DO is: " + value;
                Integer DOInt = Integer.parseInt(value);

                if (DOInt > 512)
                {
                    startService(body);

                }

            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "DO value not available !!", Toast.LENGTH_SHORT).show();
            }
        });

        pHRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                String newValue =    value  ;
                pHText.setText(newValue);
                String title = "pH Alert";
                String subject = " Your pH needs calibration !";
                String body = "The pH value is: " + value;
                Integer pHInt = Integer.parseInt(value);

                //Edit the conditions here
                if (pHInt > 512)
                {
                    startService(body);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "pH value not available !!", Toast.LENGTH_SHORT).show();
            }
        });

        sensor4Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                String newValue =    value  ;
                sensor4Text.setText(newValue);
                String title = "Sensor 4 Alert";
                String subject = " Your Sensor 4 needs calibration !";
                String body = "The Sensor 4 value is: " + value;
                Integer sensor4Int = Integer.parseInt(value);

                //Edit the conditions here
                if (sensor4Int > 512)
                {
                    startService(body);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "sensor 4 value not available !!", Toast.LENGTH_SHORT).show();
            }
        });

        sensor5Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                String newValue =    value  ;
                sensor5Text.setText(newValue);
                String title = "Sensor 5 Alert";
                String subject = " Your Sensor 5 needs calibration !";
                String body = "The Sensor 5 value is: " + value;
                Integer sensor5Int = Integer.parseInt(value);

                //Edit the conditions here
                if (sensor5Int > 512)
                {
                    startService(body);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "sensor 5 value not available !!", Toast.LENGTH_SHORT).show();
            }
        });

        sensor6Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String value = snapshot.getValue(String.class);
                String newValue =    value  ;
                sensor6Text.setText(newValue);
                String title = "Sensor 6 Alert";
                String subject = " Your Sensor 6 needs calibration !";
                String body = "The Sensor 6 value is: " + value;
                Integer sensor6Int = Integer.parseInt(value);

                //Edit the conditions here
                if (sensor6Int > 512)
                {
                    startService(body);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "sensor 4 value not available !!", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void startService(String input) {

        Intent serviceIntent = new Intent(this, ExampleService.class);
        serviceIntent.putExtra("inputExtra", input);

        ContextCompat.startForegroundService(this, serviceIntent);
    }

    public void stopService(View v) {
        Intent serviceIntent = new Intent(this, ExampleService.class);
        stopService(serviceIntent);
    }



}